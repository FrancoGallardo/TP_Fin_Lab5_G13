package DAO;

public class ConfigEnt {

}
