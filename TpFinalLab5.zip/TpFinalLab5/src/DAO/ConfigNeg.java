package DAO;

public class ConfigNeg {

}
